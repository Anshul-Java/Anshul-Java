/**
 * 
 */
package com.ice.serviceImplTest;

import java.io.File;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.junit.Ignore;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ice.commons.vo.FileReaderReqVO;
import com.ice.service.IIceBusinessService;

/**
 * @author anshu
 *
 */
public class IceBusinessServiceImpl_LargeFileTest extends TestCase {
	
	private Logger  LOG = Logger.getLogger(IceBusinessServiceImpl_LargeFileTest.class);
	
	private static ApplicationContext context = new ClassPathXmlApplicationContext("classpath:com/ice/config/spring/ice-bl.xml");

	private static IIceBusinessService service = (IIceBusinessService) context.getBean("iceBusinessService");
	
	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Test method for {@link com.ice.serviceImpl.IceBusinessServiceImpl#processCusipDetails(com.ice.commons.vo.FileReaderReqVO)}.
	 * 275MB file . This test is to check the memory usage , for easy creation I have repeated the same records multiple times.
	 */
	public void testProcessLargeCusipDetails() {
		LOG.info("testProcessLargeCusipDetails starts");
		FileReaderReqVO reqVO = new FileReaderReqVO();
		String filePath = new File("readingtest\\cusip_big.txt").getAbsolutePath();
		reqVO.setFilePath(filePath);
		service.processCusipDetails(reqVO);
		LOG.info("testProcessLargeCusipDetails Ends");
	}

}
