package com.ice.serviceImplTest;

import java.io.File;
import java.util.Comparator;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ice.commons.vo.FileMergeReqVO;
import com.ice.commons.vo.IceFileProcessingResVO;
import com.ice.service.IIceBusinessService;

public class MergeSortedFile2Test extends TestCase {
	
	private Logger  LOG = Logger.getLogger(MergeSortedFile1Test.class);
	
	private static ApplicationContext context = new ClassPathXmlApplicationContext("classpath:com/ice/config/spring/ice-bl.xml");
	
	private static IIceBusinessService service = (IIceBusinessService) context.getBean("iceBusinessService");


	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	
	/**
	 * Testing 2 column files
	 */
	public void testMergeSort2ColFile() {
		String sortedFile1 = new File("sortedTest\\2columnsort1.txt").getAbsolutePath(); 
		String sortedFile2 =  new File("sortedTest\\2columnsort2.txt").getAbsolutePath();
		FileMergeReqVO reqVO  = new FileMergeReqVO();
		reqVO.setSortedFile1(sortedFile1);
		reqVO.setSortedFile2(sortedFile2);
		reqVO.setComparator(new Comparator<String>() {
			@Override
			public int compare(String o1,
							   String o2) {
				String file1Arr[] = o1.split(",");
				String file2Arr[] = o2.split(",");
				String name1 = file1Arr[0];
				String name2 = file2Arr[0];
				if(name1.toUpperCase().compareTo(name2.toUpperCase())== 0){
					Integer col1 = Integer.valueOf(file1Arr[1]);
					Integer col2 = Integer.valueOf(file2Arr[1]);
					return col1.compareTo(col2);
				}else {
					return name1.toUpperCase().compareTo(name2.toUpperCase());
				}
			}
		});
		reqVO.setOutputFilePath(new File("sortedTest\\finalSorted2ColFile.txt").getAbsolutePath());
		
		// STEP -2 Get the Business Service instantiate using Spring DI 
		IIceBusinessService service = (IIceBusinessService) context.getBean("iceBusinessService");
		IceFileProcessingResVO resVO = service.mergeSortFile(reqVO);
		assertNotNull(resVO);
	}

}
