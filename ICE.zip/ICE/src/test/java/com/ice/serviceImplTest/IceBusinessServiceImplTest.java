/**
 * 
 */
package com.ice.serviceImplTest;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

import junit.framework.TestCase;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ice.commons.vo.FileReaderReqVO;
import com.ice.service.IIceBusinessService;

/**
 * @author anshu
 *
 */
public class IceBusinessServiceImplTest extends TestCase {
	
	private Logger  LOG = Logger.getLogger(IceBusinessServiceImplTest.class);
	
	private static ApplicationContext context = new ClassPathXmlApplicationContext("classpath:com/ice/config/spring/ice-bl.xml");

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
	}

	/* (non-Javadoc)
	 * @see junit.framework.TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Test method for {@link com.ice.serviceImpl.IceBusinessServiceImpl#processCusipDetails(com.ice.commons.vo.FileReaderReqVO)}.
	 * 3 cusips are there , so 4 Cusips will be printed with there last Rates
	 */
	public void testProcess3CusipDetails() {
		LOG.info("testProcess3CusipDetails starts");
		IIceBusinessService service = (IIceBusinessService) context.getBean("iceBusinessService");
		FileReaderReqVO reqVO = new FileReaderReqVO();
		String filePath = new File("readingtest\\cusip_with3Cusip.txt").getAbsolutePath();
		reqVO.setFilePath(filePath);
		service.processCusipDetails(reqVO);
		LOG.info("testProcess3CusipDetails Ends");
	}
	
	/**
	 * Test method for {@link com.ice.serviceImpl.IceBusinessServiceImpl#processCusipDetails(com.ice.commons.vo.FileReaderReqVO)}.
	 * 5 cusips are there , in which 1 is not of correct format, so 4 Cusips will be printed with there last Rates
	 */
	public void testProcess5CusipDetails() {
		LOG.info("testProcess5CusipDetails starts");
		IIceBusinessService service = (IIceBusinessService) context.getBean("iceBusinessService");
		FileReaderReqVO reqVO = new FileReaderReqVO();
		String filePath = new File("readingtest\\cusip_with5correct_1incorrect.txt").getAbsolutePath();
		reqVO.setFilePath(filePath);
		service.processCusipDetails(reqVO);
		LOG.info("testProcess5CusipDetails Ends");
	}
	

}
