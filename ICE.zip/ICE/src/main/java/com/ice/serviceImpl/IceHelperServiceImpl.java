package com.ice.serviceImpl;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.ice.service.IIceHelperService;

@Service("iceHelperService")
public class IceHelperServiceImpl implements IIceHelperService {
	
	private Logger  LOG = Logger.getLogger(IceHelperServiceImpl.class);

	@Override
	public <T> void printData(T object) {
		LOG.info(object);
	}

	@Override
	public <T> void printErrorData(T object) {
		LOG.error(object);
	}

	@Override
	public <T> void writeToFileInBatch(List<T> sortedList,
									   String outputFilePath) {
		FileWriter fw = null; 
		BufferedWriter bw =  null ;
		try{
				fw = new FileWriter(outputFilePath, true);
				bw = new BufferedWriter(fw, 1048576);
				LOG.info("sortedList " + sortedList);
				if(sortedList != null){
					for (int i = 0; i < sortedList.size(); i++) {
						T data = sortedList.get(i);
						fw.write(data + System.lineSeparator());
					}
				}
			}catch (Exception ex){
				
			}finally{
				try{
					if(fw != null){
						fw.close();
					}
					if(bw !=null){
						bw.close();
					}
				}catch (Exception ex){
					
				}
			}
		
		LOG.info("sortedList persisted in file successfully  ");
		
	}

}
