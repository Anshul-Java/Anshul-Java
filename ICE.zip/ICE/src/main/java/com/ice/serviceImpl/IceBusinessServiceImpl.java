package com.ice.serviceImpl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.ice.async.tasks.PrintCusipTask;
import com.ice.async.tasks.WriteTask;
import com.ice.commons.utils.ICEConstants.COMMON_CONSTS;
import com.ice.commons.utils.ICEUtils;
import com.ice.commons.vo.FileMergeReqVO;
import com.ice.commons.vo.FileReaderReqVO;
import com.ice.commons.vo.IceFileProcessingResVO;
import com.ice.service.IIceBusinessService;
import com.ice.service.IIceHelperService;

@Service("iceBusinessService")
public class IceBusinessServiceImpl implements IIceBusinessService {

	private Logger  LOG = Logger.getLogger(IceBusinessServiceImpl.class);
	
	private BlockingQueue<List<String>> queue = new ArrayBlockingQueue<List<String>>(500);
	
	private ThreadPoolExecutor singleThreadedThreadPool =  (ThreadPoolExecutor) Executors.newFixedThreadPool(1);
	
	@Autowired
	private ThreadPoolTaskExecutor threadpool;

	/**
	 * Spring based @Autowired Service 
	 */
	@Autowired
	@Qualifier("iceHelperService")
	private IIceHelperService helperService ;

	/**
	 * How much Cusip will be Processed in the batch.
	 * It can be change dynamically through JVM parameter
	 */
	@Value("${batchSize : 5}")
	private int batchSize  ;
	
	/**
	 * waitingTimePeriod before throw Exception and kill the Process.
	 * It can be change dynamically through JVM parameter
	 */
	@Value("${waitingTimePeriod : 1800000}")
	private long waitingTimePeriod ;
	
	/**
	 * Buffer size for reading which is equal to 1 MB.
	 * It can be change dynamically through JVM parameter
	 */
	@Value("${bufferSize : 1048576}")
	private int bufferSize;

	@Override
	public IceFileProcessingResVO processCusipDetails(FileReaderReqVO reqVO) {
		BufferedReader reader = null;
		FileReader fred = null;
		IceFileProcessingResVO resVO = new IceFileProcessingResVO();
		long startTime = System.currentTimeMillis();
		try{
			fred = new FileReader(reqVO.getFilePath());
			reader = new BufferedReader(fred, bufferSize);
			String currentLine = "";
			String previousCusip = "";
			String previousCusipRate = "";
			int lineNo = 1;
			Map<String,String> cusipToLastRateMap = new HashMap<>(batchSize);
			while ((currentLine = reader.readLine()) != null) {
				// STEP -1 If the currentLine is Alphanumeric
				if(isAlphaNumeric(currentLine)){
					if(!previousCusip.isEmpty() 
							&& !previousCusipRate.isEmpty()){
						cusipToLastRateMap.put(previousCusip, previousCusipRate);
					}
					// STEP -2 If the currentLine is of specified Length of Cusip
					if(isCusipOfCorrectLength(currentLine)){
						previousCusip = currentLine;
					}else {
						// STEP -3 Print this Cusip as Error , In real project it can be persisted in Audit Table.
						helperService.printErrorData("At line Number " +lineNo+ " CUSIP " + currentLine + " is not as per standard " );
						// STEP -3.1  Reset Previous Cusip Value
						previousCusip = "";
					}
				}else{
					// STEP -4 if its not cusip its rate
					if(!currentLine.isEmpty()){
						previousCusipRate = currentLine;
					}
				}
				// STEP -5 If Cusip to its Last Rate Mapping reaches the batch size send it to other thread for Processing
				if(cusipToLastRateMap.size() == batchSize){
					threadpool.execute(new PrintCusipTask(new HashMap<>(cusipToLastRateMap),helperService));
					// STEP -5.1 Clear the map to optimize memory
					cusipToLastRateMap.clear();
					LOG.debug(ICEUtils.getUsedMemory() );
				}
				lineNo++;
			}
			if(!previousCusip.isEmpty()){
				cusipToLastRateMap.put(previousCusip, previousCusipRate);
			}
			// Print remaining Cusips details
			helperService.printData(cusipToLastRateMap);
			LOG.info("Total lines Processed "+ lineNo);
			
			// STEP -6 shutdown Threadpool , if all tasks are completed or waiting time reached .
			shutdownThreadPool(startTime, threadpool.getThreadPoolExecutor());
		}catch(Exception ex){
			LOG.error("Unhandled Exception Occurred . Exception is "+ ex);
			resVO.setFailed(true);
			resVO.setErrorMessage("Unhandled Exception Occurred . Exception is "+ ex);
		}finally {
			try {
				if(fred != null){
					fred.close();
				}
				if(reader != null){
					reader.close();
				}
			} catch (Exception e) {
				LOG.error("Unhandled Exception Occurred while closing the reader . Exception is "+ e);
				resVO.setFailed(true);
				resVO.setErrorMessage("Unhandled Exception Occurred while closing the reader . Exception is "+ e);
			}
		}
		return resVO;
	}

	/**
	 * @param startTime 
	 * @throws InterruptedException 
	 * 
	 */
	private void shutdownThreadPool(long startTime, 
									ThreadPoolExecutor executer) throws Exception {
		int remainingTask = -1 ; 
		LOG.debug("Used Memory in MB " + ICEUtils.getUsedMemory() );
		while(remainingTask != 0){
			remainingTask = getRemainingTasks(executer) ; 
			LOG.info("remainingTask " +remainingTask );
			Thread.sleep(5l);
			LOG.debug("Used Memory in MB " + ICEUtils.getUsedMemory() );
			 if((System.currentTimeMillis() - startTime) == waitingTimePeriod){
				 executer.shutdown();
				 throw new RuntimeException("Process not completed in specfied time period");
			 }
		}
		executer.shutdown();
		LOG.info("SHUTDOWN completed");
	}

	private int getRemainingTasks(ThreadPoolExecutor executer) {
		int queuedTask = executer.getQueue().size();
		int activeTask = executer.getActiveCount();
		return queuedTask + activeTask;
	}

	/**
	 * 
	 * @param line
	 * @return
	 */
	private boolean isCusipOfCorrectLength(String line) {
		return line.length()==8;
	}

	private boolean isAlphaNumeric(String line){
		return line.matches(COMMON_CONSTS.ALPHA_NUM_CONST);
	}
	
	
	
	//@Override
	/**
	 * 
	 */
	public IceFileProcessingResVO mergeSortFile(FileMergeReqVO reqVO) {
		
		BufferedReader readerFile1= null, readerFile2 = null;
		FileReader fredFile1= null, fredFile2 = null;
		IceFileProcessingResVO resVO = new IceFileProcessingResVO();
		List<String> sortedList = new ArrayList<String>(batchSize);
		long startTime = System.currentTimeMillis();
		try{
			fredFile1 = new FileReader(reqVO.getSortedFile1());
			readerFile1 = new BufferedReader(fredFile1, bufferSize);
			fredFile2 = new FileReader(reqVO.getSortedFile2());
			readerFile2 = new BufferedReader(fredFile2, bufferSize);
			String readLineFile1 = "";
			String readLineFile2 = "";
			singleThreadedThreadPool.submit(new WriteTask(queue,
														  reqVO.getOutputFilePath(),
														  helperService));
			int lineNo = 1;
			// STEP -1 Compare the 2 files based on Comparator provided 
			while(readerFile1.ready() 
					&& readerFile2.ready()){
				if(lineNo == 1){
					readLineFile1 = readerFile1.readLine();
					readLineFile2 = readerFile2.readLine();
				}
				if(readLineFile1 != null 
						&& readLineFile2 != null){
					if(reqVO.getComparator().compare(readLineFile1,readLineFile2)<=0){
						sortedList.add(readLineFile1);
						readLineFile1 = readerFile1.readLine();
					}else{
						sortedList.add(readLineFile2);
						readLineFile2 = readerFile2.readLine();
					}
				}
				lineNo++;
				// STEP -2 if sorted List reaches the batch size , then push this into queue for writing into file.
				if(sortedList.size() >= batchSize){
					queue.put(new ArrayList<String>(sortedList));
					sortedList.clear();
				}
			}
			
			// STEP -3 if after comparison , there are some entries left in File1( either file1 can have some entries or file2 not both have entries left ) then push it into sorted list
			while ((readLineFile1 = readerFile1.readLine()) != null) {
				sortedList.add(readLineFile1);
			}
			
			// STEP -4 if after comparison , there are some entries left in File2( either file1 can have some entries or file2 not both have entries left ) then push it into sorted list
			while ((readLineFile2 = readerFile2.readLine()) != null) {
				sortedList.add(readLineFile2);
			}
			
			// STEP - 5 Now if the remaining sorted List size is more than BatchSize then push in batches to Queue
			if(sortedList.size()> batchSize){
				pushDataInBatchToQueue(sortedList);
			}else{
				queue.put(new ArrayList<String>(sortedList));
			}
			sortedList.clear();
			
			// STEP - 6 EOF file entry push into queue to exist the runnable task
			queue.put(Arrays.asList(new String[]{"EOF"}));
			
			// STEP - 7 Shutdown the Executer task
			shutdownThreadPool(startTime,singleThreadedThreadPool);
			
		}catch(Exception ex) {
			LOG.error("Unhandled Exception Occurred . Exception is "+ ex);
			resVO.setFailed(true);
			resVO.setErrorMessage("Unhandled Exception Occurred . Exception is "+ ex);
		}finally {
			try{
				if(fredFile1 != null){
					fredFile1.close();
				}
				if(readerFile1 != null){
					readerFile1.close();
				}
				if(fredFile2 != null){
					fredFile2.close();
				}
				if(readerFile2 != null){
					readerFile2.close();
				}
			}catch (Exception e) {
				LOG.error("Unhandled Exception Occurred while closing the reader . Exception is "+ e);
				resVO.setFailed(true);
				resVO.setErrorMessage("Unhandled Exception Occurred while closing the reader . Exception is "+ e);
			}
			
		}
		
		return resVO;
	}

	/**
	 * 
	 * @param sortedList
	 * @throws Exception
	 */
	private void pushDataInBatchToQueue(List<String> sortedList)throws Exception {
		int size = sortedList.size();
		int numberOfBatches = size/batchSize;
		int lastBatch = size - (numberOfBatches * batchSize);
		int startIndex = 0;
		int endIndex = startIndex + batchSize;
		int count = 1;
		while (count <= numberOfBatches) {
			queue.put(new ArrayList<String>(sortedList.subList(startIndex, endIndex)));
			startIndex = endIndex ;
			endIndex = startIndex + batchSize;
			count++;
		}
		
		if(lastBatch != 0){
			queue.put(new ArrayList<String>(sortedList.subList(startIndex, startIndex + lastBatch)));
		}
	}
	
}
