/**
 * 
 */
package com.ice.commons.utils;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

/**
 * @author anshu
 *
 */
public interface ICEConstants {
	
	
	public interface FILE_CONSTS{
		public final static Charset ENCODING = StandardCharsets.UTF_8;
	}
	
	public interface COMMON_CONSTS{
		public final static String ALPHA_NUM_CONST = "^(?=[^\\s]*?[0-9])(?=[^\\s]*?[a-zA-Z])[a-zA-Z0-9]*$";
	}

}
