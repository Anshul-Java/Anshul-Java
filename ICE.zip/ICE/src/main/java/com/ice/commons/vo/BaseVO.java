/**
 * 
 */
package com.ice.commons.vo;

/**
 * @author anshu
 * This VO act as a common VO and have common attributes that can be used in the entire app
 */
public class BaseVO {

}
