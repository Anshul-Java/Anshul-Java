/**
 * 
 */
package com.ice.commons.utils;

/**
 * @author anshu
 *
 */
public class ICEUtils {
	
	private static final long  MEGABYTE = 1024L * 1024L;
	
	private static long toTalMemory = Runtime.getRuntime().totalMemory();
	
	
	private ICEUtils(){
		
	}
	
	public static long getUsedMemory(){
		Runtime rt = Runtime.getRuntime();
		return   ((Runtime.getRuntime().totalMemory() - rt.freeMemory()) / MEGABYTE);

	}

}
