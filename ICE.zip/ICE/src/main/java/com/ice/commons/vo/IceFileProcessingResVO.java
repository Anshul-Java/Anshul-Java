package com.ice.commons.vo;

public class IceFileProcessingResVO extends BaseVO {
	
	private String errorMessage;

	private boolean failed;
	
	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public boolean isFailed() {
		return failed;
	}

	public void setFailed(boolean failed) {
		this.failed = failed;
	}

}
