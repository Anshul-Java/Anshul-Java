/**
 * 
 */
package com.ice.commons.vo;

import java.util.Comparator;

/**
 * @author anshu
 *
 */
public class FileMergeReqVO extends BaseVO {
	
	private String sortedFile1; 
	private String sortedFile2;
	private Comparator<String> comparator;
	private String outputFilePath;
	
	public String getSortedFile1() {
		return sortedFile1;
	}
	public void setSortedFile1(String sortedFile1) {
		this.sortedFile1 = sortedFile1;
	}
	public String getSortedFile2() {
		return sortedFile2;
	}
	public void setSortedFile2(String sortedFile2) {
		this.sortedFile2 = sortedFile2;
	}
	public Comparator<String> getComparator() {
		return comparator;
	}
	public void setComparator(Comparator<String> comparator) {
		this.comparator = comparator;
	}
	public String getOutputFilePath() {
		return outputFilePath;
	}
	public void setOutputFilePath(String outputFilePath) {
		this.outputFilePath = outputFilePath;
	}

}
