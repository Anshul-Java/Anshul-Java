/**
 * 
 */
package com.ice.service;

import com.ice.commons.vo.FileMergeReqVO;
import com.ice.commons.vo.FileReaderReqVO;
import com.ice.commons.vo.IceFileProcessingResVO;

/**
 * @author anshu
 *
 */
public interface IIceBusinessService {
	
	public IceFileProcessingResVO processCusipDetails(FileReaderReqVO reqVO);
	
	public IceFileProcessingResVO mergeSortFile(FileMergeReqVO reqVO);

}
