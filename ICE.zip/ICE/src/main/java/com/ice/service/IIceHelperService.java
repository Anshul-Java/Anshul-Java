/**
 * 
 */
package com.ice.service;

import java.util.List;

/**
 * @author anshu
 *
 */
public interface IIceHelperService {
	
	public <T>void  printData(T object);
	
	public <T>void  printErrorData(T object);
	
	public <T>void  writeToFileInBatch(List<T> list, String outputFilePath);

}
