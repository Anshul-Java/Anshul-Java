package com.ice.async.tasks;

import java.util.List;
import java.util.concurrent.BlockingQueue;

import org.apache.log4j.Logger;

import com.ice.service.IIceHelperService;

public class WriteTask implements Runnable{
	
	private BlockingQueue<List<String>> queue;
	
	private String outputFilePath;
	
	private Logger  LOG = Logger.getLogger(WriteTask.class);
	
	/**
	 * Spring based Service
	 */
	private IIceHelperService helperService ;
	
	public WriteTask(BlockingQueue<List<String>> queue,
					 String outputFilePath,
					 IIceHelperService helperService){
		this.queue = queue;
		this.outputFilePath = outputFilePath;
		this.helperService = helperService;
	}

	@Override
	public void run() {
		boolean busySpiningFlag = true;
		try {
			while(busySpiningFlag){
				List<String> sortedList = queue.take();
				busySpiningFlag = (sortedList != null && sortedList.get(0).equals("EOF")? false : true);
				if(busySpiningFlag 
						&& sortedList != null){
					helperService.writeToFileInBatch(sortedList, outputFilePath);
				}
			}
		} catch (Exception e) {
			LOG.error("Unhandled Exception Occurred "+ e);
			throw new RuntimeException("Unhandled Exception Occurred "+ e);
		}
		
	}
	
}