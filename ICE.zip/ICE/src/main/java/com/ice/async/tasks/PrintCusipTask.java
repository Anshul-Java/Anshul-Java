/**
 * 
 */
package com.ice.async.tasks;

import java.util.Map;

import com.ice.service.IIceHelperService;

/**
 * @author anshu
 *
 */
public class PrintCusipTask implements Runnable {
	
	/**
	 * Spring based Service
	 */
	private IIceHelperService helperService ;
	
	private Map<String,String> cusipMap;
	
	public PrintCusipTask(Map<String,String> cusipMap,
						  IIceHelperService helperService){
		this.cusipMap = cusipMap;
		this.helperService = helperService;
	}

	@Override
	public void run() {
		helperService.printData(cusipMap);
		this.cusipMap.clear();
		this.cusipMap=null; // immediately make it available for next GC
	}

}
