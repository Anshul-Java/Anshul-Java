package com.ice.main;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ice.commons.vo.FileReaderReqVO;
import com.ice.commons.vo.IceFileProcessingResVO;
import com.ice.service.IIceBusinessService;

public class IceFileReaderMain {
	
	private static ApplicationContext context = new ClassPathXmlApplicationContext("classpath:com/ice/config/spring/ice-bl.xml");
	
	private static Logger  LOG = Logger.getLogger(IceFileReaderMain.class);
	
	public static void main(String[] args) {
		// STEP -1 Assuming file path is passed as a method argument 
		String filePath = args[0];
		
		// STEP -2 Prepare the Request VO 
		FileReaderReqVO reqVO = new FileReaderReqVO();
		reqVO.setFilePath(filePath);
		
		// STEP -3 Get the Business Service instantiate using Spring DI 
		IIceBusinessService service = (IIceBusinessService) context.getBean("iceBusinessService");
		
		long startTime = System.currentTimeMillis();
		
		IceFileProcessingResVO resVO = service.processCusipDetails(reqVO);
		
		// STEP -4 In Case of Failure , process exit with code 1 to be captured by calling Shell script 
		if(resVO.isFailed()){
			LOG.info(" Time taken " + (System.currentTimeMillis() - startTime) + " in Miliseconds");
			System.exit(1);
		}
		LOG.info(" Time taken " + (System.currentTimeMillis() - startTime + " in Miliseconds"));
	}

}
