package com.ice.main;

import java.util.Comparator;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ice.commons.vo.FileMergeReqVO;
import com.ice.commons.vo.IceFileProcessingResVO;
import com.ice.service.IIceBusinessService;

public class IceFileMergeMain {
	
	private static ApplicationContext context = new ClassPathXmlApplicationContext("classpath:com/ice/config/spring/ice-bl.xml");
	
	private static Logger  LOG = Logger.getLogger(IceFileMergeMain.class);
	
	
	public static void main(String[] args) {
		// STEP -1 Assuming file paths are passed as a method argument 
		String sortedFile1 = args[0];
		String sortedFile2 = args[1];
		
		FileMergeReqVO reqVO  = new FileMergeReqVO();
		reqVO.setSortedFile1(sortedFile1);
		reqVO.setSortedFile2(sortedFile2);
		reqVO.setComparator(new Comparator<String>() {
			@Override
			public int compare(String o1, String o2) {
				Integer col1 = Integer.valueOf(o1.split(",")[0]);
				Integer col2 = Integer.valueOf(o2.split(",")[0]);
				return col1.compareTo(col2) ;
			}
		});
		reqVO.setOutputFilePath("C:\\Users\\anshu\\myjavastuff\\output\\finalSortedFile.txt");
		
		// STEP -2 Get the Business Service instantiate using Spring DI 
		IIceBusinessService service = (IIceBusinessService) context.getBean("iceBusinessService");
		
		long startTime = System.currentTimeMillis();
		
		IceFileProcessingResVO resVO = service.mergeSortFile(reqVO);
		
		// STEP -4 In Case of Failure , process exit with code 1 to be captured by calling Shell script 
		if(resVO.isFailed()){
			LOG.info(" Time taken " + (System.currentTimeMillis() - startTime) + " in Miliseconds");
			System.exit(1);
		}
		LOG.info(" Time taken " + (System.currentTimeMillis() - startTime + " in Miliseconds"));
	}

}
